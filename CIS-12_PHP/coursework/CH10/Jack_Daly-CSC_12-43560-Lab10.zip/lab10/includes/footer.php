<!--
// Jack Daly 🥷
// CSC 12-43560
// Updated 03/06/22
-->
</div>
<footer class="footer">
    <div class="container">
        <p class="text-muted">Copyright &copy; 2022</p>
    </div>
</footer>
</body>
</html>
