<div class="canister">
	<div class="post">
		<h2>RECENT POSTS</h2>
		<?php displayPosts('public'); ?>
	</div>
	<div class="sidebar">
		<?php displaySearch(); ?>
		<?php displayPostBox(); ?>
	</div>
</div>