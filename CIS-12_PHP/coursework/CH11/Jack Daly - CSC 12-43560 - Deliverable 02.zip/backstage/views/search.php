<div class="canister">
	<div class="post">
		<h2>Search Results</h2>
		<?php displayPosts('search'); ?>
	</div>
	<div class="sidebar">
		<?php displaySearch(); ?>
		<?php displayPostBox(); ?>
	</div>
</div>