<div class="canister">
	<div class="post">
		<h2>YOUR POSTS</h2>
		<?php displayPosts('yourposts'); ?>
	</div>
	<div class="sidebar">
		<?php displaySearch(); ?>
		<?php displayPostBox(); ?>
	</div>
</div>